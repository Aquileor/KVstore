#Reyes Aquileo
#Class Project Step 10 

1. If a user inputs the proper URL (https://www...Html) then it will take them to my project website.

2. The user will then have the option to sign in as a user by inputting your username and password in the top right of the page so that they can edit or use the data.

3. If the user does not have a current account they much select Create account button next to the sign in button, so that thye can have permissions to use the website and pull or edit the Geospatial data.

4. Once they user has complete access of the website the user will have the option to search for specific Geospatial data with the search function on the top center of the page, so that you can look for specific data and edit or pull that spefic datset.

5.If they don't use the search function there will be an option button on the top left of the main page to Input data such as a CVS file, but will have to match the proper naming convention and data structure.

6.If they don't use the Input function there will be an option button on the top left of the main page to Pull data such as a CVS file, so that you can use that data on a system like ArcMap.

7. If they don't use the Pull function there will be an option button on the top left of the main page to edit data such as a CVS file, but it still had to meet certain data conventions.

8. If you don’t use the search function on the top center side of the pageor the three othere fuctions listed above, then there will be a list of different random data sets in the middle left side of the page. 

9. After you determine which data you want to look at then you have the option to select and populate that data on the map that will be on the right side of the page.

10. The map on the right side will allow the user to visually depict what data they selected and they will have the option to change the map background in order to make the data look more appealing on the map.

11. The user will also have a drop down arrow from the data on the middle left side of the page so they can query the data into specific data type such as (points, lines or polygons).

12. If the user does not want to use the drop down arrow as well they can just double click on any of the data sets that they would like to look at.

13. Once the user selected that specific data type it will take them to that specific data type were they will see the whole table.

14. The user will have the option to select the metadata that if they want to see more information on that specific data set.

15. If the user does not want to look at the metadata then that have the option to edit the table as long as it meets the proper contends.

16. If the user does not want to look at the metadata or edit the table then they have the option to pull that data so that they can pull that cvs file to use in a different system such as ArcMap.

17. When the user is done editing or pulling the data they will then have the option to save what they did on the bottom left of the page. 

18. This will then give the user the option if they want to stay in that specific data page or go back to the main menu to search for another data type.

19. Once the user is back on the main page they can choose to logout by selecting the sign out button on the top right.

20. If they sign out it will take them to the main sign in menu and if they don’t sign out then the can keep on working.

21. There will be a quick survey at then end so there can be feedback from the user.
